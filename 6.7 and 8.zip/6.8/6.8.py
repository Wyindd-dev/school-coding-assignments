import random

def main():
    #open a file named random.txt
    random_file = open(r'C:\Users\25JHarrington\Downloads\python\6.7\random.txt')

    #gets the numbers from the file
    numbers = random_file.read()

    #print lines to screen
    print(numbers)

    #close the file
    random_file.close()

#call the main function
main()