import random

def main():
    #open a file named random.txt
    random_file = open(r'C:\Users\25JHarrington\Downloads\python\6.7\random.txt', 'w')

    #get the number of random numbers to write
    num_of_random = int(input('How many random numbers should I write? '))

    #write the random numbers to the file
    for count in range(1, num_of_random + 1):
        #generate a random number
        random_number = random.randint(1, 500)

        #write the random number to the file
        random_file.write(str(random_number) + '')

    #close the file
    random_file.close()
    print('Data written to random.txt')

#call the main function
main()
